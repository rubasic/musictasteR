globalVariables(
  c(
   "year",
   "artist_name",
   "track_name"
  )
)
