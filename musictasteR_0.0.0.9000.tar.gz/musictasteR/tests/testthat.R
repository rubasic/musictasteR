library(testthat)
library(musictasteR)

test_check("musictasteR")
